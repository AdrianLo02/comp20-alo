var express = require("express");
var mongo = require('mongodb');
var app = express();

app.use(express.json());
app.use(express.urlencoded());

// Cross-domain scripting
app.all('/submit.json', function(req, res, next) {
	res.header("Access-Control-Allow-Origin", "*");
  	res.header("Access-Control-Allow-Headers", "X-Requested-With");
  	next();
 });

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/A4';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

app.get('/scores.json', function(req, res) {
	res.set('Content-Type', 'text/json');
	var user = req.query.username;
	db.collection("scores", function(err, col) {
		col.find({"username":user}).sort({score:-1}).limit(100).toArray(function(er, elems){
			var theString = JSON.stringify(elems);
			res.send(theString);
		})
	})
});

app.post('/submit.json', function (req, res){
    var name = req.body.username;
	var score = req.body.score;
    var grid = req.body.grid;
    var timestamp = new Date()
    db.collection("scores", function (err, collection){
      	var submission = { "username": name, "score": score, "grid": grid, "created_at": timestamp}
      	collection.insert(submission, function (err, saved) {
      		res.send(200);
      	});
    });
});

app.get('/', function (req, res) {
	res.set('Content-Type', 'text/html');
	res.set('title', '2048 Game Center');
	var theResponse = '<!DOCTYPE html><html><head><title>2048 Game Center</title><META CHARSET = "UTF-8"></head><body><h1>2048 High Scores</h1>';
	var closing = '</body></html>'
	var table = '<table><tr><th>Score</th><th>Username</th><th>Date</th></tr>';
	db.collection("scores", function(err, col) {
		col.find({}).sort({score:-1}).limit(100).toArray(function(er, elems){
			for (i = 0; i < elems.length; i++) {
				table += '<tr><td>' + elems[i].score + '</td><td>' + elems[i].username + '</td><td>' + elems[i].created_at + '</td></tr>';
			}
			table += '</table>';
			theResponse += table;
			theResponse += closing;
			res.send(theResponse);
		});
	});
});

var port = Number(process.env.PORT || 5000);
app.listen(port, function() {
  	console.log("Listening on " + port);
});
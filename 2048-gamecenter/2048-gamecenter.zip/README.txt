2048 Game Center
by Adrian Lo

This is a web application that uses Express and MongoDB to store scores for the game 2048.